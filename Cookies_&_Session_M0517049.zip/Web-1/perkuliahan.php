<!DOCTYPE html>
<html lang="id">

<?php
    $name = 'language';
  $value = 'english';
  $expire = time() + 60*60*24*3; // 3 days from now
  $path = '/Users/wildanazmizulvana/Desktop/Semester4/Pemweb/Web-1';
  $domain = 'index.php';
  $secure = isset($_SERVER['HTTPS']); // or use true/false
  $httponly = true;
  setcookie($name, $value, $expire, $path, $domain, $secure, $httponly);
?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Waladun's Personal Blog - Seluruh cerita dan pengalaman perkuliahan ada disini</title>
    <meta name="Description" content="Sebuah blog yang berisi sedikit pengalaman dan penggambaran dunia perkuliahan di UNS">
    <meta name="Keywords" content="informatika, uns, blog, story">

    <link rel="icon" href="images/icon.png" type="image/x-icon" />

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <div class="container">
        <div class="cover">
            <h1> Waladun's Personal Blog</h1>
        </div>
        <ul class="navbar">
            <li><a href="index.php"><i class="fas fa-home"></i> Beranda</a></li>
            <li class="active" ><a href="perkuliahan.php">Perkuliahan</a></li>
            <li><a href="pengalaman.php">Pengalaman</a></li>
            <li><a href="biodata.php">Biodata</a></li>
            <li><a href="about-solo.php">Kontak</a></li>
            <li>
                <div class="dropdown">
                    <button class="dropdown-menu">
                        Informasi UNS <i class="fa fa-caret-down"></i>
                    </button>
                    <div class="dropdown-content">
                        <a href="https://uns.ac.id/en/">Website UNS</a>
                        <a href="https://spmb.uns.ac.id">SPMB UNS</a>
                        <a href="https://spada.uns.ac.id/">Spada</a>
                    </div>
                </div>
            </li>
        </ul>
        <div class="content">
            <div class="row main-content main-content-left">
                <div class="news-item">
                    <h1> Dunia Perkuliahan </h1>
                    <span class="help-text"><strong>Wildan Azmi Zulvana </strong> - Sabtu, 13 Apr 2019 19:00 WIB</span>
                    <p> Masuk dalam dunia perkuliahan merupakan salah satu hal yang paling membanggakan. Bersyukur rasanya bisa belajar sampai tingkat universitas karena tidak semua orang punya kesempatan untuk belajar sampai tingkat perguruan tinggi. Tahun 2017 saya masuk UNS (Universitas Sebelas Maret), rasanya senang sekali bisa masuk di salah satu PTN terbaik di Indonesia. Saya masuk prodi Informatika, walaupun sebenarnya tidak ada passion di bidang itu namun saya mencoba untuk terus belajar disini. Sekarang saya sudah memasuki semester 4 dan pelajaran yang saya dapatkan cukup beragam dan mayoritas belajar tentang logika dan perhitungan. <br> Berikut tips dan trik agar mendapat nilai tinggi dalam dunia perkuliahan:</p> 
                        <p> 1. Kosongkan Pikiran Saat Menerima Materi</p>
                        <p>Ibarat gelas kosong siap menerima air untuk diisi, itulah perumpamaan pikiran yang harus disiapkan ketika menerima materi perkuliahan. Walaupun beberapa materi yang disampaikan lebih bersifat pengulangan karena sudah pernah diperoleh ketika di bangku SMA, tetapi kamu tidak boleh meremehkan materi tersebut. Seperti bumi yang terus berputar, dunia pendidikan pun mengalami perkembangan. Pembaharuan keilmuan itulah yang penting untuk dipahami, bahkan kita bisa mengkolaborasikannya dengan pengetahuan yang sudah diperoleh sebelumnya untuk menambah kualitas kompetensi yang dimiliki.</p>
                        <p> 2. Jangan Malas Mencatat</p>
                        <p> Kehidupan ‘mahasiswa zaman now’ semakin dimanjakan dengan pesatnya kemajuan teknologi di mana mereka tidak perlu repot mencatat bahan ajar yang disampaikan dosen tetapi cukup meminta soft file bahan ajar tersebut. Walaupun terkesan praktis, apakah bahan ajar tersebut dibaca dan dipelajari kembali? Atau sekedar koleksi yang hanya dibuka sekali-kali? Kemajuan teknologi memang memberikan kemudahan, namun tanpa disadari hal ini telah menurunkan minat baca dan menulis di kalangan mahasiswa.<br>Perlu diketahui lho, dengan mencatat bahan ajar akan memberikan kamu keuntungan, karena selain tangan bekerja untuk menulis secara otomatis mata dan otak pun membaca dan memahami materi tersebut. Untuk itu, tetap disarankan untuk memiliki buku catatan dan kelompokan sesuai dengan mata kuliahnya karena dapat membantu untuk mempelajari materi perkuliahan dengan baik. Catatan yang lengkap juga berpengaruh terhadap tingkat pemahaman. Jika kamu hanya mempelajari bahan ajar dalam bentuk softfile, terkadang ada beberapa penjelasan materi yang disampaikan dan dijelaskan oleh dosen namun tidak tertera dalam softfile tersebut.</p>
                        <p> 3. Menjadi Mahasiswa Aktif</p>
                        <p>Selain fokus menerima materi dan mencatatnya, kamu juga harus bisa memanfaatkan setiap pertemuan di kelas untuk berdiskusi secara langsung dengan dosen. Seperti mengajukan pertanyaan ataupun menjawab pertanyaan yang diajukan dosen. Hal tersebut seringkali menjadi nilai tambah tersendiri, karena secara perlahan dosen pun akan ingat pada nama kita.<br>Meski terkesan seperti cari muka, tetapi cara ini masuk ke dalam ranah positif dan salah satu rahasia yang dilakukan mahasiswa cerdas untuk mendapatkan IPK tertinggi. Manfaatkan kesempatan, apalagi jika dalam satu kelas banyak yang bersemangat untuk maju kedepan kelas mengerjakan soal, pasti dosen pun akan memberikan penilaian yang baik untuk kelas secara keseluruhan. So, jangan pernah malu dan jangan pernah takut salah untuk tujuan yang positif. </p>
                        <p> 4.  Kerjakan Tugas Tepat Waktu</p>
                        <p>Pernah dengar istilah SKS atau ‘Sistem Kebut Semalam’? Istilah ini pasti tidak asing lagi di telinga mahasiswa, terutama mereka yang menjadi mahasiswa tingkat akhir. Kebiasaan yang sangat tidak disarankan ini merupakan tanda-tanda kemalasan mulai menghampiri. Hingga tak jarang kita lebih sering menggerutu pada dosen yang memberikan tugas, bukan berusaha mengubah kebiasaan menunda pekerjaan. So, mulai sekarang kerjakan setiap tugas yang diberikan dengan tepat waktu. Selain lebih maksimal dan terstruktur dalam menyelesaikannya, kamu pun tidak akan merasa terbebani ketika banyaknya tugas yang menghampiri.Usahakan juga untuk mengumpulkan tugas tepat waktu ya, karena bisa berpengaruh pada penilaiannya lho.</p>
                
                    <p> Semoga tips yang saya berikan mengenai dunia perkuliahan bisa memberikan motivasi agar lebih semangat mengejar cita - cita dan berpretasi dalam kuliah. Btw, barangkali kalian kepo tentang matkul apa saja yang saya ambil, dibawah ini merupakan jadwal saya semster 4 ini:</p>
                    <table class="table">
                    <tbody>
                        <tr>
                            <th>Senin</th>
                            <th>Selasa</th>
                            <th>Rabu</th>
                            <th>Kamis</th>
                            <th>Jumat</th>
                        </tr>
                        <tr>
                            <td> - </td>
                            <td> Komputer Grafik </td>
                            <td>Jaringan Komputer</td>
                            <td>-</td>
                            <td>Metode Numerik</td>
                        </tr>
                        <tr>
                            <td> - </td>
                            <td>Komputer Grafik</td>
                            <td>Jaringan Komputer</td>
                            <td>-</td>
                            <td>Metode Numerik</td>
                        </tr>
                        <tr>
                            <td> Pemrograman Web </td>
                            <td>Praktikum</td>
                            <td>Jaringan Komputer</td>
                            <td>-</td>
                            <td>-</td>
                        </tr>
                        <tr>
                            <td>Pemrograman Web</td>
                            <td>Praktikum</td>
                            <td>-</td>
                            <td>Open Source</td>
                            <td>-</td>
                        </tr>
                        <tr>
                            <td>Praktikum</td>
                            <td>Praktikum</td>
                            <td>-</td>
                            <td>Open Source</td>
                            <td>-</td>
                        </tr>
                        <tr>
                            <td>Praktikum</td>
                            <td>Praktikum</td>
                            <td>-</td>
                            <td>Rekayasa Perangkat Lunak</td>
                            <td>-</td>
                        </tr>
                        <tr>
                            <td>Riset Operasi</td>
                            <td>-</td>
                            <td>Asisten Dosen </td>
                            <td>Rekayasa Perangkat Lunak</td>
                            <td>Praktikum</td>
                        </tr>
                        <tr>
                            <td>Riset Operasi</td>
                            <td>-</td>
                            <td></td>
                            <td>Rekayasa Perangkat Lunak</td>
                            <td>Praktikum</td>
                        </tr>
                        <tr>
                            <td> Riset Operasi </td>
                            <td>Praktikum</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                        </tr>
                        <tr>
                            <td>-</td>
                            <td>Praktikum</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                        </tr>
                        <tr>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                        </tr>
                    </tbody>
                </table>
                <p> Di semester 4 ini saya mengambil 21 SKS dengan 5 praktikum dan 1 makul sebagai asisten dosesn yaitu makul Organisasi Sistem Komputer (OSK). Semoga semakin menambah semangat belajar! Amiin.</p>
                </div>
            </div>
        </div>
    </div>
        <footer>
            <p>&copy; Wildan Azmi Zulvana - 2019 </p>
        </footer>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <script src="js/script.js"></script>
</body>
</html>