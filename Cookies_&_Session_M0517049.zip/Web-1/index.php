<!DOCTYPE html>
<html lang="id">

<?php
    $name = 'language';
  $value = 'english';
  $expire = time() + 60*60*24*3; // 3 days from now
  $path = '/Users/wildanazmizulvana/Desktop/Semester4/Pemweb/Web-1';
  $domain = 'index.php';
  $secure = isset($_SERVER['HTTPS']); // or use true/false
  $httponly = true;
  setcookie($name, $value, $expire, $path, $domain, $secure, $httponly);
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Waladun's Personal Blog - Seluruh cerita dan pengalaman perkuliahan ada disini</title>
    <meta name="Description" content="Sebuah blog yang berisi sedikit pengalaman dan penggambaran dunia perkuliahan di UNS">
    <meta name="Keywords" content="informatika, uns, blog, story">

    <link rel="icon" href="images/icon.png" type="image/x-icon" />

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <div class="container">
        <div class="cover">
            <h1> Waladun's Personal Blog</h1>
        </div>
        <ul class="navbar">
            <li class="active"><a href="index.php"><i class="fas fa-home"></i> Beranda</a></li>
            <li><a href="perkuliahan.php">Perkuliahan</a></li>
            <li><a href="pengalaman.php">Pengalaman</a></li>
            <li><a href="biodata.php">Biodata</a></li>
            <li><a href="kontak.php"> Kontak</a></li>
            <li>
                <div class="dropdown">
                    <button class="dropdown-menu">
                        Informasi UNS <i class="fa fa-caret-down"></i>
                    </button>
                    <div class="dropdown-content">
                        <a href="https://uns.ac.id/en/">Website UNS</a>
                        <a href="https://spmb.uns.ac.id">SPMB UNS</a>
                        <a href="https://spada.uns.ac.id/">Spada</a>
                    </div>
                </div>
            </li>
        </ul>
        <div class="content">
            <div class="row main-content main-content-left">
                <div class="news-item">
                    <h1><i>Selamat Datang!!!</i><br>
                        <?php

                    session_start(); //start the PHP_session function 

                    if(isset($_SESSION['page_count']))
                    {
                         $_SESSION['page_count'] += 1;
                    }
                    else
                    {
                         $_SESSION['page_count'] = 1;
                    }
                    echo 'Kamu adalah pengunjung ke ' . $_SESSION['page_count'];
                     session_destroy(); //destroy entire session 

                        ?>
                        <br> <br>Wildan Azmi Zulvana</h1>
                    <h3>Informatika UNS 2017</h3>
                    <p> Terima kasih telah mengunjungi blog ini. Dalam blog ini saya akan menceritakan pengalaman dan kisah unik mengenai dunia perkuliahan khuusnya di Informatika UNS. Saya juga akan memberikan tips - tips agar bisa beradaptasi dengan mudah di lingkungan yang baru terutama di lingkungan perkuliahan. Untuk anak - anak yang ingin tahu lebih banyak tentang UNS (Universitas Sebelas Maret), seluruh informasinya bisa kalian lihat di website - website UNS yang ada pada blog ini. Terdapat website pembelajaran UNS juga yang dibuat khusus untuk mempermudah sistem pembelajaran dalam perkuliahan.</p><br>
                    <p class="p1">
                    Yaa, kali ini saya akan membagikan 'tips and trick' agar bisa mendapatkan nilai tinggi di perkuliahan. <br></p>
                    <a href="perkuliahan.php">Kuy Pantengin</a>
                </div>
            </div>
        </div>
        <footer>
            <p>&copy; Wildan Azmi Zulvana - 2019 </p>
        </footer>
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <script src="js/script.js"></script>
</body>
</html>