<!DOCTYPE html>
<html lang="id">

<?php
    $name = 'language';
  $value = 'english';
  $expire = time() + 60*60*24*3; // 3 days from now
  $path = '/Users/wildanazmizulvana/Desktop/Semester4/Pemweb/Web-1';
  $domain = 'index.php';
  $secure = isset($_SERVER['HTTPS']); // or use true/false
  $httponly = true;
  setcookie($name, $value, $expire, $path, $domain, $secure, $httponly);
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Waladun's Personal Blog - Seluruh cerita dan pengalaman perkuliahan ada disini</title>
    <meta name="Description" content="Sebuah blog yang berisi sedikit pengalaman dan penggambaran dunia perkuliahan di UNS">
    <meta name="Keywords" content="informatika, uns, blog, story">

    <link rel="icon" href="images/icon.png" type="image/x-icon" />

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <div class="container">
        <div class="cover">
            <h1> Waladun's Personal Blog</h1>
        </div>
        <ul class="navbar">
            <li><a href="index.php"><i class="fas fa-home"></i> Beranda</a></li>
            <li><a href="perkuliahan.php">Perkuliahan</a></li>
            <li class="active"><a href="pengalaman.php">Pengalaman</a></li>
            <li><a href="biodata.php">Biodata</a></li>
            <li><a href="kontak.php">Kontak</a></li>
            <li>
                <div class="dropdown">
                    <button class="dropdown-menu">
                        Informasi UNS <i class="fa fa-caret-down"></i>
                    </button>
                    <div class="dropdown-content">
                        <a href="https://uns.ac.id/en/">Website UNS</a>
                        <a href="https://spmb.uns.ac.id">SPMB UNS</a>
                        <a href="https://spada.uns.ac.id/">Spada</a>
                    </div>
                </div>
            </li>
        </ul>
        <div class="content">
            <div class="row main-content main-content-left">
                <div class="news-item">
                    <h1> Cerita dan Pengalaman di UNS</h1>
                    <span class="help-text"><strong>Wildan Azmi Zulvana </strong> - Minggu, 14 Apr 2019 13:00 WIB</span><br>
                     <video class="vid" width="990" height="420" controls>
                        <source src="video/informatics2017.mp4" type="video/mp4">
                        Your browser does not support the video tag.
                    </video>
                    <p> Video diatas merupakan kumpulan foto - foto yang diambil dari masa ospek prodi (osprodi). Kalian semua pasti mengerti osprodi itu apa terutama mahasiswa baru. Sudah merupakan kewajiban bagi mahasiswa baru untuk melewati masa tersebut. Disini saya akan bercerita mengenai pengalaman - pengalaman dan sedikit pencapaian yang telah saya peroleh selama menjalani perkuliahan di UNS.<br><br>
                    Seperti yang sudah saya ceritakan diawal, saya masuk UNS tahun 2017. Prodi yang saya pilih yaitu informatika. Ya, informatika merupakan salah satu prodi paling prospektif di perguruan tinggi. Pertama kali tau bahwa saya diterima di UNS prodi Informatika rasanya campur aduk. Rasa senang karena berhasil lolos SBMPTN dan masuk jurusan yang prospektif sekaligus rasa bingung karena saya tidak punya dasar dan tidak tau apa - apa tentang informatika atau bisa dibilang saya termasuk siswa yang gagap teknologi. <br><br>
                    Rasa bingung itu kemudian berubah menjadi minder ketika saya pertama kali bertemu teman - teman saya pertama kalinya yaitu saat registrasi ulang. Mereka semua terlihat memiliki basic IT yang cukup tinggi. Sedangkan saya, kelas 3 SMA saja tidak bisa membuat sebuah slide presentasi (power point). Bisa dibayangkan betapa awamnya saya waktu itu. Setelah registrasi, kami menjalani ospek. Mulai dari ospek tingkat universitas, tingat fakultas, dan tingkat jurusan/prodi. Saya mengenal banyak teman melalui ospek tersebut. Saling berbagi keluh kesah tentang masa transisi yang sulit, harus jauh dari orang tua, dan harus hidup mandiri. <br><br>
                    Yang paling berkesan adalah ketika ospek prodi (osprodi). Karena osprodi merupakan proses ospek terberat dan terlama selama awal memasuki universitas. Setelah sebelumnya dalam ospek universitas dan ospek fakultas kami semua dipisah, dalam osprodi saya bertemu kembali dengan teman - teman jurusan saya sendiri yang nantinya menjadi partner saya sampai lulus. Rasa minder itu muncul lagi ketika kami berjumpa dalam satu ruangan kelas yang sama dan berbincang sedikit mengenai perkembangan teknologi yang ada. Untungnya, dalam masa osprodi ini, sebagian besar tugas yang diberikan tidak menyangkut dunia informatika. Tugas - tugas yang diberikan bertujuan agar kami bisa bekerja sama dengan baik dan mengenal satu sama lain, serta lebih mengenal lingkungan kampus dengan baik. Tugas yang diberikan contohnya seperti berfoto di seluruh fakultas, membuat denah UNS,dll. Disitu mulai timbul rasa kepercayaan diri sedikit demi sedikit setelah mengenal teman - teman jurusan. <br><br>
                    Setelah masa osprodi selesai, menandakan berakhirnya seluruh masa ospek kami di UNS yang artinya kami resmi menjadi mahasiswa Informatika UNS angkatan 2017. Beberapa bulan kemudian, ada "open recruitment" dari Himaster. Yaa himaster merupakan himpunanan mahasiswa jurusan yang tujuannya menyelenggarakan seluruh aktivitas mahasiswa di kampus termasuk ospek prodi. Dalam himaster tersebut terdapat banyak pilihan bidang tergantung prioritas bidang yang kita minati. Singkat cerita saya masuk di pilihan pertama, yaitu bidang minat dan bakat (mikat). Mikat bertugas untuk mengkoordinir dan menyelenggarakan seluruh aktivitas mahasiswa yang bergerak pada bidang olahraga dan kesenian, seperti futsal, badminton, basket, musik,dll. Bidang mikat juga wajib mengikuti kepanitiaan dalam Himaster dalam menyelenggarakan event - event. Disana saya belajar untuk berinteraksi dengan orang banyak secara sopan, menghadapi orang lain yang tidak sepaham dan sepemikiran dengan kita secara baik dan benar, belajar mengkoordinir orang - orang disekitar kita dalam menghadapai masalah - masalah yang muncul dan menemukan solusi yang bijak dan tidak merugikan semua pihak,dll. Di semester 3, masa jabatan saya di organisasi tersebut telah selesai dan saya memutuskan untuk tidak ikut pada periode selanjutnya dikarenakan ingin lebih fokus kuliah. <br><br>
                    Semester 3 dimulai, beban kuliah semakin berat dikarenakan praktikum yang semakin banyak. Di semester sebelumnya saya masih bisa main dan nongkrong setiap malam tanpa memikirkan tugas yang ada, namun di semester 3 ini saya merasa kuliah saya semakin serius dan tidak bisa dibuat mainan. Di semester 3 saya mengambil 23 SKS. Iya, saya mencoba untuk mengambil mata kuliah full. Di masa inilah saya mulai berjuang menyukai apa yang seharusnya menjadi bidang saya. Di semester 3 ini saya mendapatkan salah satu mata kuliah wajib yaitu Basis Data, jumlah SKSnya cukup banyak yaitu 4 SKS. Mau tidak mau saya harus lulus makul ini karena kalo tidak, nilai saya pasti tidak aman karena beban SKSnya yang cukup besar. Setelah UTS, dosen Basis Data saya memberikan pengumuman adanya sertifikasi untuk mata kuliah Basis Data. Sertifikasi ini diselenggarakan oleh Microsoft yang bekerja sama dengan prodi Informatika UNS. Kami diberikan waktu kurang lebih 2 bulan untuk mempersiapkan sertifikasi tersebut.<br><br>
                    Dosen Basis Data saya, Bu Sari namanya menyampaikan bahwa apabila kita ingin lulus mata kuliahnya maka kami harus lulus sertifikasi dari Microsoft yaitu sertifikasi MTA (Microsoft Technology Association). Keuntungan yang kami dapatkan dari sertifikasi MTA sangatlah penting untuk penunjang dan memberikan nilai plus ketika akan mencari pekerjaan. Syarat untuk lulus sertifikasi adalah 65. Jika lulus sertifikasi, kami bisa mendapatkan gelar MTA yang berlaku seumur hidup dari Microsoft yang akan menunjang kita dalam dunia pekerjaan. Dan akhirnya ketika waktu tes tiba, saya mengerjakan dengan penuh optimisme karena Bu Sari sebelumnya sudah menggembleng kami selama 2 minggu untuk membabat habis materi agar kami dapat lulus sertifikasi. Nilai akan langsung muncul ketika sudah mengerjakan sertifikasi. Dan alhamdulillah ketika klik tombol "finish", saya merasa puas karena nilai saya lulus sertifikasi MTA dan saya berhak atas gelar MTA. <br><br>
                    Ya itulah cerita singkat tentang pengalaman dan sedikit pencapaian saya semasa menjalanai kuliah di Informatika UNS. Dari mulai awal masuk perkuliahan sampai sekarang semester 4 saya tetap menjaga semangat belajar agar bisa mendapatkan ilmu untuk mengejar cita - cita. Semoga sedikit cerita dari saya bisa memberikan motivasi untuk kalian.<br> Tetap Semangat!!! <br>
                    “Do you want to know who you are? Don’t ask. Act! Action will delineate and define you.” <br>- Thomas Jefferson

                     </p>
                </div>
            </div>
        </div>  <div class="comment-section">
                    <h3 style="margin-bottom: 0px;"><i class="fas fa-comment"></i> Komentar</h3>
                    <h4>Menampilkan <strong>2</strong> komentar.</h4>
                    <p>Beri saya komentar agar saya bisa berbagi cerita lebih banyak dan baik lagi...</p>
                    <div class="comment-list">
                        <div class="comment-item">
                            <div class="comment-box">
                                <div class="comment-content">
                                    <div class="comment-author">
                                        <span style="font-weight: bold;">Zainul Ma'rufin</span>
                                        <div class="time">
                                            <span class="help-text">zainul@student.uns.ac.id - 15/04/2019, 12:10 PM</span>
                                        </div>
                                    </div>
                                    <div class="comment-body">
                                        <p>Ceritanya sangat menginspirasi karena itu juga yang saya rasakan bang Wildan, semoga bisa terus memberikan motivasi lewat cerita - cerita singkatnya!.</p>
                                        <a href="#" class="button right"><i class="fas fa-reply"></i> Balas</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="comment-item">
                            <div class="comment-box">
                                <div class="comment-content">
                                    <div class="comment-author">
                                        <span style="font-weight: bold;">Alfitra Adam</span>
                                        <div class="time">
                                            <span class="help-text">alftr_adam@student.uns.ac.id - 04/06/2019, 9:57:22 PM</span>
                                        </div>
                                    </div>
                                    <div class="comment-body">
                                        <p> Terkadang emang suka down kalo liat temen yang lain udah pada bisa ini itu kak, tapi saya yakin berkat perjuangan semua bisa dicapai. Terima kasih untuk sedikit cerita yang memberikan motivasi ini.</p>
                                        <a href="#" class="button right"><i class="fas fa-reply"></i> Balas</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div>
                            <div class="comment-item">
                                    <p><i class="fas fa-comment-medical"></i> Tuliskan komentar baru...</p>
                                    <a href="#" class="button" id="new-comment"><i class="fas fa-plus"></i> Komentar Baru</a>
                                    <div class="new-comment-block">
                                        <form id="form-komentar" action="#" method="POST">
                                            <strong>Nama</strong>
                                            <br>
                                            <span class="help-text form-help-text">Minimal memasukkan 5 huruf.</span>
                                            <input type="text" name="name" id="name" placeholder="Masukkan nama kamu...">
                                            <strong>E-mail Address</strong>
                                            <br>
                                            <span class="help-text form-help-text">Masukkan email address.</span>
                                            <input type="email" name="email" id="email" placeholder="Masukkan email kamu...">
                                            <strong>Komentar</strong>
                                            <br>
                                            <span class="help-text form-help-text">Masukkan minimal 30 karakter komentar dan harus bersifat membangun.</span>
                                            <textarea name="komentar" id="komentar" cols="30" rows="10" placeholder="Masukkan komentar kamu..."></textarea>
                                            <button type="submit"><i class="fas fa-plus"></i> Kirim</button>
                                        </form>
                                    </div>
                                </div>
                    </div>
                </div>
            <footer>
            <p>&copy; Wildan Azmi Zulvana - 2019 </p>
        </footer>
    </div>
     <a href="javascript:" id="return-to-top"><i class="fas fa-chevron-circle-up"></i></a>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <script async defer src="https://buttons.github.io/buttons.js"></script>
    <script src="js/script.js"></script>
</body>
</html>